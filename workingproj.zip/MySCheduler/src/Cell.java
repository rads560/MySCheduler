public class Cell {
	String day;
	int time;
	String username;
	String color;
	
	public Cell(String day, int time, String username, String color) {
		this.day = day;
		this.time = time;
		this.username = username;
		this.color = color;
	}
}