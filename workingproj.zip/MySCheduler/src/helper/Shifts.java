package helper;

public class Shifts {
	String day;
	int time;
	
	public Shifts(String day, int time) {
		this.day = day;
		this.time = time;
	}
}